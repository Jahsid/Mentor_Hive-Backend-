export const USER_STORE_PERSIST="xc8vj*>t6g7";
export const TOKEN="5fshgbs*>TUbXxuh";